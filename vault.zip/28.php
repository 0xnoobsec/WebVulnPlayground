<?php include 'includes/header.php';?>
<?php include 'includes/navbar.php';?>

<center> <a class="btn btn-success" href="https://8c23e1e6980a70602ce4b7d738e35e3a.security-pedia.com/" target="_blank">GO TO CHALLENGE</a></center>

<!-- start from the beginning of a pentest -->

<?php include 'includes/footer.php';?>

