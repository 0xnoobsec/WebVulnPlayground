<?php include 'includes/header.php';?>
<?php include 'includes/navbar.php';?>
<nav>
<ul><li><a href="chall3.php">More</a></li></ul>
</nav>

<?php include 'includes/footer.php';?>
