<?php include 'includes/header.php';?>
<?php include 'includes/navbar.php';?>

<center> <a class="btn btn-success" href="https://ac2ae6bc49d94ce23080ae2e29460d60.security-pedia.com/" target="_blank">GO TO CHALLENGE</a></center>
<!-- You Must Exploit A Server Side Bug -->
<?php include 'includes/footer.php';?>

